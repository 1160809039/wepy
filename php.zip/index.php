<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/29
 * @desc:
 */

phpinfo();