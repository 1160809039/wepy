<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/14
 * @desc:
 */

namespace app\index\service;


use app\index\model\AddressInfo;
use app\index\model\TaskInfo;
use app\index\model\TaskReceiveInfo;
use app\index\model\UserInfo;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;

class TaskInfoService
{
   public function getTaskList($page,$size,$schoolId,$state){
       try {
           return TaskInfo::where(['school_id' => $schoolId, "state" => $state])->order("create_time desc")->limit(($page-1)*$size,$size)->select();
       } catch (Exception $e) {
           return $e->getMessage();
       }

   }

    public function saveTask($taskName,$taskWeight,$taskPrice,$schoolId,$openid,$addressId,$consigneeName,$consigneeMobile){
        try {
            $task=new TaskInfo();
            $task->task_name=$taskName;
            $task->task_weight=$taskWeight;
            $task->task_price=$taskPrice;
            $task->school_id=$schoolId;
            $user=null;
            try {
                $user=  UserInfo::where('openid', $openid)->find();
            } catch (Exception $e) {
                return $e->getMessage();
            }
            if($user==null){
                return null;
            }
            $task->user_id=$user->id;
            $task->user_avatar=$user->avatar_url;

            $task->address_id=$addressId;
            $task->consignee_name=$consigneeName;
            $task->consignee_mobile=$consigneeMobile;
            $task->state=0;
            $task->create_time=date('Y-m-d H:i:s',time());
            $success=$task->save();
            if($success){
                return $task;
            }
            else{
                return null;
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

    public function updateTask($taskName,$taskWeight,$taskPrice,$schoolId,$openid,$addressId,$consigneeName,$consigneeMobile,$id){
        try {
            $task=TaskInfo::where("id",$id)->find();
            if($task==null){
                return null;
            }
            $task->task_name=$taskName;
            $task->task_weight=$taskWeight;
            $task->task_price=$taskPrice;
            $task->school_id=$schoolId;
            $user=null;
            try {
                $user=  UserInfo::where('openid', $openid)->find();
            } catch (Exception $e) {
                return $e->getMessage();
            }
            if($user==null){
                return null;
            }
            $task->user_id=$user->id;
            $task->user_avatar=$user->avatar_url;

            $task->address_id=$addressId;
            $task->consignee_name=$consigneeName;
            $task->consignee_mobile=$consigneeMobile;
            $task->state=0;
            $task->create_time=date('Y-m-d H:i:s',time());
            $success=$task->save();
            if($success){
                return $task;
            }
            else{
                return null;
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }


    public function  getTaskById($taskId){

       $user=null;
       $task=null;
        try {
            $task=  TaskInfo::where("id", $taskId)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($task==null){
            return null;
        }

        $userId=$task->user_id;
        $addressId=$task->address_id;
        try {
            $user = UserInfo::where("id", $userId)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        $address=null;
        try {
            $address = AddressInfo::where("id", $addressId)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }

        $task->visible(["id","task_name","task_weight","task_price","create_time"]);
        $task->nick_name=$user->nick_name;
        $task->consignee_name=$address->consignee_name;
        $task->consignee_mobile=$address->consignee_mobile;
        $task->address_id=$address->id;
        $task->address=$address->branch_courts.' '.$address->department_name.' '.$address->specific_address;
        $task->specific_address=$address->specific_address;
        $task->append(['nick_name',"address","consignee_name","consignee_mobile","specific_address","address_id"]);

        return $task;
    }


    public  function  selectTaskByOpenId($openid){
       $user=null;

        try {
            $user = UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($user==null){
            return null;
        }

        try {
            $task = TaskInfo::with('address', 'LEFT')->where("task_info.user_id=". $user->id." and (task_info.state=0 or task_info.state=1)")->order("state asc, create_time desc")->select();
            return $task;
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }


    public  function  deleteTaskById($id){
        $task=null;

        try {
            $task = TaskInfo::where("id", $id)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($task==null){
            return null;
        }

        try {
            try {
                $success = $task->delete();
                if($success){
                    return $task;
                }

            } catch (Exception $e) {
                return $e->getMessage();
            }

        } catch (Exception $e) {
            return $e->getMessage();
        }
        return null;
    }

    public  function  selectTaskMinePublish($openid,$page,$size){
        $user=null;

        try {
            $user = UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($user==null){
            return null;
        }

        try {
            $task = TaskInfo::with('address', 'LEFT')->where(["task_info.user_id"=> $user->id," task_info.state"=>"3"])->order("state asc, create_time desc")->limit(($page-1)*$size,$size)->select();
            return $task;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }


}