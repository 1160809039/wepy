<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/25
 * @desc:
 */

namespace app\index\service;


use app\index\model\AddressInfo;
use app\index\model\UserInfo;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;

class AddressService
{
   public function saveAddress($consigneeName,$mobile,$isdefault,$branchcourts,$departmentname,$specificaddress,$openid){
       $user=null;
       try {
           $user=  UserInfo::where('openid', $openid)->find();
       } catch (Exception $e) {
           return $e->getMessage();
       }
       if($user==null){
           return null;
       }

       if($isdefault=="0"){
           AddressInfo::where("user_id",$user->id)->update(['is_default' => '1']);
       }

       $address=new AddressInfo();
       $address->consignee_name=$consigneeName;
       $address->consignee_mobile=$mobile;
       $address->is_default=$isdefault;
       $address->branch_courts=$branchcourts;
       $address->department_name=$departmentname;
       $address->user_id=$user->id;
       $address->state='0';
       $address->specific_address=$specificaddress;
       $address->create_time=date('Y-m-d H:i:s',time());
       $success=$address->save();
       if($success){
           return $address;
       }else{
           return null;
       }
   }
    public function editAddress($consigneeName,$mobile,$isdefault,$branchcourts,$departmentname,$specificaddress,$openid,$id){
        $user=null;
        try {
            $user=  UserInfo::where('openid', $openid)->find();
        } catch (Exception $e) {
            return null;
        }
        if($user==null){
            return null;
        }
        $address=null;

        try {
            $address=  AddressInfo::where('id', $id)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($address==null){
            return null;
        }


        if($isdefault=="0"){
            AddressInfo::where("user_id",$user->id)->update(['is_default' => '1']);
        }
        $address->consignee_name=$consigneeName;
        $address->consignee_mobile=$mobile;
        $address->is_default=$isdefault;
        $address->branch_courts=$branchcourts;
        $address->department_name=$departmentname;
        $address->user_id=$user->id;
        $address->specific_address=$specificaddress;
        $address->modified_time=date('Y-m-d H:i:s',time());
        $success=$address->save();
        if($success){
            return $address;
        }else{
            return null;
        }
    }

    public function addressList($openid){
        $user=null;
        try {
            $user=  UserInfo::where('openid', $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($user==null){
            return null;
        }

        try {
            return  AddressInfo::where(["user_id"=>$user->id,"state"=>"0"])->order("is_default asc,id desc")->select();
        } catch (Exception $e) {
            return $e->getMessage();
        }


    }
    public function selectAddress($id){

        try {
            return  AddressInfo::where("id", $id)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }


    }


    public  function selectDefault($openid){
        $user=null;
        try {
            $user=  UserInfo::where('openid', $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($user==null){
            return null;
        }
        try {
            return  AddressInfo::where(["user_id"=>$user->id,"is_default"=>"0"])->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }


    public  function deleteAddress($id){

        try {
            $address=  AddressInfo::where("id",$id)->find();
            if($address==null){
                return null;
            }

            $address->state="1";
            $success=$address->save();
            if($success){
                return $address;
            }else{
                return null;
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }


}