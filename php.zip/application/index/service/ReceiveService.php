<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/26
 * @desc:
 */

namespace app\index\service;


use app\index\model\TaskInfo;
use app\index\model\TaskReceiveInfo;
use app\index\model\UserInfo;
use think\Db;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;

class ReceiveService
{
    public  function  saveReceiveInfo($taskId,$openid,$id){

        $user=null;
        $taker=null;
        $task=null;
        try {
            $user = UserInfo::where("id", $id)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }

        try {
            $taker = UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        try {
            $task = TaskInfo::where("id", $taskId)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }

        if($user==null||$taker==null||$task==null){
            return null;
        }
        Db::startTrans();
        try{
            $pick=new TaskReceiveInfo();
            $pick->task_name=$task->task_name;
            $pick->task_weight=$task->task_weight;
            $pick->task_price=$task->task_price;
            $pick->user_avatar=$user->avatar_url;
            $pick->task_id=$task->id;
            $pick->user_id=$task->user_id;
            $pick->taker_id=$taker->id;
            $pick->state=0;
            $pick->create_time=date('Y-m-d H:i:s',time());
            $success= $pick->save();
            if($success){
                TaskInfo::where("id",$taskId)->update(["state"=>"1"]);
                Db::commit();
                return $task;
            }
        }catch (Exception $e){
            Db::rollback();
        }

          return null;

    }

    public  function  selectReceive($openid){
        $user=null;

        try {
            $user = UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        $user_id=$user->id;
        try {
            return TaskReceiveInfo::where(["taker_id" => $user_id, "state" => "0"])->select();
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

    public  function  updateReceiveEnd($receiveId){
        $receive=null;

        try {
            $receive = TaskReceiveInfo::where("id", $receiveId)->find();
            if($receive==null){
                return null;
            }
            Db::startTrans();
            $taskId=$receive->task_id;
            $receive->state='1';
            $receive->modified_time=date('Y-m-d H:i:s',time());
            $success=  $receive->save();
            if($success){
                $taskSuccess=TaskInfo::where("id",$taskId)->update(["state"=>"2"]);
                if($taskSuccess){
                    Db::commit();
                    return $receive;
                }else{
                    Db::rollback();
                }
            }else{
                Db::rollback();
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
        return null;

    }

    public  function  updateReceiveDelete($receiveId){
        $receive=null;

        try {
            $receive = TaskReceiveInfo::where("id", $receiveId)->find();
            if($receive==null){
                return null;
            }
            Db::startTrans();
            $taskId=$receive->task_id;

            try {
                $success = $receive->delete();
            } catch (Exception $e) {
                Db::rollback();
                return $e->getMessage();
            }
            if($success){
                $taskSuccess=TaskInfo::where("id",$taskId)->update(["state"=>"0"]);
                if($taskSuccess){
                    Db::commit();
                    return $receive;
                }else{
                    Db::rollback();
                }
            }else{
                Db::rollback();
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
        return null;

    }

    public  function  selectTaskConfirmed($openid){
        $user=null;

        try {
            $user = UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($user==null){
            return null;
        }

        try {
            $task = TaskReceiveInfo::with('user',"LEFT")->where(["task_receive_info.user_id" => $user->id, "task_receive_info.state" => "1"])->select();
            return $task;
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }
    public  function  selectTaskMineOver($openid,$page,$size){
        $user=null;

        try {
            $user = UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        if($user==null){
            return null;
        }

        try {
            $task = TaskReceiveInfo::with('publishuser', 'LEFT')->where("task_receive_info.taker_id=". $user->id." and (task_receive_info.state=1 or task_receive_info.state=2)")->order("state asc, modified_time desc")->limit(($page-1)*$size,$size)->select();
            return $task;
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }


    public  function  updateReceiveConfirmEnd($receiveId){
        $receive=null;

        try {
            $receive = TaskReceiveInfo::where("id", $receiveId)->find();
            if($receive==null){
                return null;
            }
            Db::startTrans();
            $taskId=$receive->task_id;
            $receive->state='2';
            $receive->modified_time=date('Y-m-d H:i:s',time());
            $success=  $receive->save();
            if($success){
                $taskSuccess=TaskInfo::where("id",$taskId)->update(["state"=>"3"]);
                if($taskSuccess){
                    Db::commit();
                    return $receive;
                }else{
                    Db::rollback();
                }
            }else{
                Db::rollback();
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
        return null;

    }







}