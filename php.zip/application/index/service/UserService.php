<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/25
 * @desc:
 */

namespace app\index\service;


use app\index\model\UserInfo;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;

class UserService
{
   public function saveUser($openid,$avatar,$nickname){
       $user=new UserInfo();
       $user->openid=$openid;
       $user->avatar_url=$avatar;
       $user->nick_name=$nickname;
       $user->create_time=date('Y-m-d H:i:s',time());
       $sucess= $user->save();
       if($sucess){
           return $user;
       }else{
           return null;
       }
   }
    public function updateUser($openid,$avatar,$nickname){
        try {
            $user = UserInfo::where('openid', $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }
        $user->avatar_url=$avatar;
        $user->nick_name=$nickname;
        $user->modified_time=date('Y-m-d H:i:s',time());
        $sucess= $user->save();
        if($sucess){
            return $user;
        }else{
            return null;
        }
    }
    public function selectUser($openid){
        try {
            return UserInfo::where("openid", $openid)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }
    public function selectUserById($id){
        try {
            return UserInfo::where("id", $id)->find();
        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

}