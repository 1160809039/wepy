<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/25
 * @desc:
 */

namespace app\index\controller;


use app\index\service\AddressService;
use think\Controller;

class AddressController extends Controller
{
    public $addressService;

    public function __construct(){
        parent::__construct();
        $this->addressService=new AddressService();
    }

    public function saveAddress($consigneeName,$mobile,$isdefault,$branchcourts,$departmentname,$specificaddress,$openid){

       return $this->addressService->saveAddress($consigneeName,$mobile,$isdefault,$branchcourts,$departmentname,$specificaddress,$openid);
    }

    public function editAddress($consigneeName,$mobile,$isdefault,$branchcourts,$departmentname,$specificaddress,$openid,$id){
        return $this->addressService->editAddress($consigneeName,$mobile,$isdefault,$branchcourts,$departmentname,$specificaddress,$openid,$id);
    }

    public function addressList($openid){
        return $this->addressService->addressList($openid);
    }

    public function selectAddress($id){
        return $this->addressService->selectAddress($id);
    }

    public  function selectDefault($openid){
        return $this->addressService->selectDefault($openid);
    }
    public  function deleteAddress($id){
        return $this->addressService->deleteAddress($id);
    }
}