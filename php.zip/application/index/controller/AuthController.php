<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/17
 * @desc:
 */

namespace app\index\controller;


use app\index\service\UserService;
use think\Controller;

class AuthController extends  Controller
{
    public $userService;

    public function __construct(){
        parent::__construct();
        $this->userService=new UserService();
    }

   public function getOpenId($code){
       $url='https://api.weixin.qq.com/sns/jscode2session?appid=wx769534252da8f614&secret=18e789b883b8c335bb534abd13025104&js_code='.$code.'&grant_type=authorization_code';
       $ch = curl_init();

       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_HEADER, 1);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
//       curl_setopt($ch, CURLOPT_POST, 1);
       $response = curl_exec($ch);
       if (curl_getinfo($ch, CURLINFO_HTTP_CODE) == '200') {
           $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
           $header = substr($response, 0, $headerSize);
           $body = substr($response, $headerSize);
       }
       curl_close($ch);

//       json_encode($body)->openid;

       return  $body;
   }

    public function getAceessToken(){
        $url='https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx769534252da8f614&secret=18e789b883b8c335bb534abd13025104';
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
//       curl_setopt($ch, CURLOPT_POST, 1);
        $response = curl_exec($ch);
        if (curl_getinfo($ch, CURLINFO_HTTP_CODE) == '200') {
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $header = substr($response, 0, $headerSize);
            $body = substr($response, $headerSize);
        }
        curl_close($ch);

//       json_encode($body)->openid;

        return  $body;
    }

    public function login($openid,$avatar,$nickname){

        if( $this->userService->selectUser($openid)==null){
            return json($this->userService->saveUser($openid,$avatar,$nickname)) ;
        } else{
            return   json($this->userService->updateUser($openid,$avatar,$nickname));
        }
    }

    public function selectUser($id){
       return $this->userService->selectUserById($id);
    }
}