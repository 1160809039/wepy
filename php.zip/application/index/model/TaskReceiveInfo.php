<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/26
 * @desc:
 */

namespace app\index\model;


use think\Model;

class TaskReceiveInfo extends Model
{
    protected $table = 'task_receive_info';
    protected $connection = 'db_config';


    public function user()
    {
        return $this->belongsTo('UserInfo','taker_id')->bind([
            "nick_name",
            "avatar_url"
        ])->setEagerlyType(0);
    }

//    public function task()
//    {
//        return $this->belongsTo('TaskInfo','task_id')->bind([
//            "user_id"
//        ])->setEagerlyType(0);
//    }


    public function publishuser()
    {
        return $this->belongsTo('UserInfo','user_id')->bind([
            "nick_name"
        ])->setEagerlyType(0);
    }
}