<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/14
 * @desc:
 */

namespace app\index\model;


use think\Model;

class TaskInfo extends Model
{
    protected $table = 'task_info';
    protected $connection = 'db_config';

    public function address()
    {
        return $this->belongsTo('AddressInfo','address_id')->bind([
            "branch_courts",
            "department_name",
            "specific_address"
        ])->setEagerlyType(0);


    }

    public function user()
    {
        return $this->belongsTo('UserInfo','user_id')->bind([
            "id"=>"user_id"
        ])->setEagerlyType(0);


    }
}