<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

Route::get('think', function () {
    return 'hello,ThinkPHP5!';
});

Route::get('hello/:name', 'index/hello');
Route::get('error', 'index/error');
Route::rule('tasklist','index/TaskController/getTaskList','POST');
Route::rule('saveTask','index/TaskController/saveTask','POST');
Route::rule('saveReceive','index/TaskController/saveReceive','POST');
Route::rule('selectReceive','index/TaskController/selectReceive','POST');
Route::rule('getTaskById','index/TaskController/getTaskById','POST');
Route::rule('updateReceiveEnd','index/TaskController/updateReceiveEnd','POST');
Route::rule('updateReceiveDelete','index/TaskController/updateReceiveDelete','POST');
Route::rule('selectTaskByOpenId','index/TaskController/selectTaskByOpenId','POST');
Route::rule('selectTaskConfirmed','index/TaskController/selectTaskConfirmed','POST');
Route::rule('deleteTaskById','index/TaskController/deleteTaskById','POST');
Route::rule('updateTask','index/TaskController/updateTask','POST');
Route::rule('selectTaskMineOver','index/TaskController/selectTaskMineOver','POST');
Route::rule('updateReceiveConfirmEnd','index/TaskController/updateReceiveConfirmEnd','POST');
Route::rule('selectTaskMinePublish','index/TaskController/selectTaskMinePublish','POST');



Route::rule('getOpenId','index/AuthController/getOpenId','POST');
Route::rule('login','index/AuthController/login','POST');
Route::rule('selectUser','index/AuthController/selectUser','POST');
Route::rule('getAceessToken','index/AuthController/getAceessToken','POST');


Route::rule('saveAddress','index/AddressController/saveAddress','POST');
Route::rule('addressList','index/AddressController/addressList','POST');
Route::rule('editAddress','index/AddressController/editAddress','POST');
Route::rule('selectAddress','index/AddressController/selectAddress','POST');
Route::rule('selectDefault','index/AddressController/selectDefault','POST');
Route::rule('deleteAddress','index/AddressController/deleteAddress','POST');


return [

];
