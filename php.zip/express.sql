/*
 Navicat Premium Data Transfer

 Source Server         : 本地
 Source Server Type    : MySQL
 Source Server Version : 50549
 Source Host           : localhost:3306
 Source Schema         : express

 Target Server Type    : MySQL
 Target Server Version : 50549
 File Encoding         : 65001

 Date: 29/09/2018 21:14:29
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for address_info
-- ----------------------------
DROP TABLE IF EXISTS `address_info`;
CREATE TABLE `address_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `consignee_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人姓名',
  `consignee_mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人手机号',
  `is_default` tinyint(2) NULL DEFAULT NULL COMMENT '0 默认 ',
  `branch_courts` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分院名称',
  `department_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '院系名称',
  `specific_address` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '具体地址',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `modified_time` datetime NULL DEFAULT NULL COMMENT '修改时间',
  `state` tinyint(2) NULL DEFAULT NULL COMMENT '0 正常 1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of address_info
-- ----------------------------
INSERT INTO `address_info` VALUES (1, '李逍遥', '12536578478', 1, '信息与控制工程学院', '计算机应用技术', '15计算机2班 A楼202教室', 6, '2018-09-20 13:37:51', NULL, 1);
INSERT INTO `address_info` VALUES (2, '张有为', '18458887548', 1, '信控', '计算机', '15计算机2班', 6, '2018-09-25 19:21:06', '2018-09-28 16:41:55', 0);
INSERT INTO `address_info` VALUES (3, '邵泽铭', '18457451248', 0, '信息控制学院', '计算机', '15栋427', 6, '2018-09-26 11:35:18', '2018-09-29 11:37:20', 0);
INSERT INTO `address_info` VALUES (4, '邵有才', '15548795876', 1, '信控', '计算机', '508寝室', 6, '2018-09-26 13:50:12', '2018-09-28 16:41:34', 0);

-- ----------------------------
-- Table structure for task_info
-- ----------------------------
DROP TABLE IF EXISTS `task_info`;
CREATE TABLE `task_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '快递名称',
  `task_weight` decimal(10, 2) NULL DEFAULT NULL COMMENT '快递重量',
  `task_price` decimal(10, 2) NULL DEFAULT NULL COMMENT '代拿价格',
  `school_id` int(11) NULL DEFAULT NULL COMMENT '学校id',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '发布人id',
  `user_avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '发布人头像',
  `address_id` bigint(20) NULL DEFAULT NULL COMMENT '地址id',
  `consignee_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人姓名',
  `consignee_mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人手机号',
  `state` tinyint(2) NULL DEFAULT NULL COMMENT '0 等待中  ,1 接单中 ,2 待完成 ,3 已完成 ,4 删除',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `modified_time` datetime NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_schoolId_state`(`school_id`, `state`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of task_info
-- ----------------------------
INSERT INTO `task_info` VALUES (1, '华为手机', 39.00, 4.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 1, '张不凡', '18455824587', 0, '2018-09-19 17:56:57', NULL);
INSERT INTO `task_info` VALUES (2, '电饭锅', 25.00, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 2, '王麻子', '18455824588', 0, '2018-09-19 18:00:49', NULL);
INSERT INTO `task_info` VALUES (3, '漫画', 8.60, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 3, '张起灵', '15478952489', 2, '2018-09-19 18:05:11', NULL);
INSERT INTO `task_info` VALUES (4, '茶杯', 2.50, 4.00, 1001, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 1, '赵友倩', '13566874589', 2, '2018-09-19 18:06:05', NULL);
INSERT INTO `task_info` VALUES (5, '洗衣机', 45.00, 2.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 2, '张不凡', '18455824587', 0, '2018-09-19 17:56:57', NULL);
INSERT INTO `task_info` VALUES (7, '一双鞋', 32.00, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 3, '张起灵', '15478952489', 2, '2018-09-19 18:05:11', NULL);
INSERT INTO `task_info` VALUES (8, '衣服', 222.00, 2.00, 1001, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 2, '赵友倩', '13566874589', 1, '2018-09-19 18:06:05', NULL);
INSERT INTO `task_info` VALUES (9, '耐克鞋', 39.00, 4.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 1, '张不凡', '18455824587', 0, '2018-09-19 17:56:57', NULL);
INSERT INTO `task_info` VALUES (10, '袜子', 25.00, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 1, '王麻子', '18455824588', 0, '2018-09-19 18:00:49', NULL);
INSERT INTO `task_info` VALUES (11, '方便面', 8.60, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 2, '张起灵', '15478952489', 2, '2018-09-19 18:05:11', NULL);
INSERT INTO `task_info` VALUES (12, '零食一堆', 2.50, 4.00, 1001, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 3, '赵友倩', '13566874589', 1, '2018-09-19 18:06:05', NULL);
INSERT INTO `task_info` VALUES (13, '桌子', 45.00, 2.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 3, '张不凡', '18455824587', 0, '2018-09-19 17:56:57', NULL);
INSERT INTO `task_info` VALUES (14, '花', 34.00, 5.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 2, '王麻子', '18455824588', 0, '2018-09-19 18:00:49', NULL);
INSERT INTO `task_info` VALUES (15, '蛋糕', 32.00, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 1, '张起灵', '15478952489', 0, '2018-09-19 18:05:11', NULL);
INSERT INTO `task_info` VALUES (16, '衣服2', 222.00, 2.00, 1001, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 1, '赵友倩', '13566874589', 3, '2018-09-19 18:06:05', NULL);
INSERT INTO `task_info` VALUES (17, '洗衣机2', 45.00, 2.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 2, '张不凡', '18455824587', 0, '2018-09-19 17:56:57', NULL);
INSERT INTO `task_info` VALUES (18, '两双鞋', 32.00, 3.00, 1001, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 3, '张起灵', '15478952489', 0, '2018-09-19 18:05:11', NULL);
INSERT INTO `task_info` VALUES (19, '夹克衫', 1.00, 1.00, 1001, 6, 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTILEE8TK9vgB8wggRUPgqrgicSVLVWrqwAAHfa9ia74m0n3dBdicQ0INESlxmVUoALYVM3ZQJRh3Bsgw/132', 3, '邵泽铭', '18457451248', 0, '2018-09-26 16:40:12', NULL);
INSERT INTO `task_info` VALUES (20, '巧克力', 15.80, 1.50, 1001, 6, 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTILEE8TK9vgB8wggRUPgqrgicSVLVWrqwAAHfa9ia74m0n3dBdicQ0INESlxmVUoALYVM3ZQJRh3Bsgw/132', 2, '张有为', '18458887548', 2, '2018-09-28 17:09:34', NULL);
INSERT INTO `task_info` VALUES (22, '旧衣服', 1.00, 3.00, 1001, 6, 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTILEE8TK9vgB8wggRUPgqrgicSVLVWrqwAAHfa9ia74m0n3dBdicQ0INESlxmVUoALYVM3ZQJRh3Bsgw/132', 4, '邵有才', '15548795876', 0, '2018-09-28 16:59:09', NULL);

-- ----------------------------
-- Table structure for task_receive_info
-- ----------------------------
DROP TABLE IF EXISTS `task_receive_info`;
CREATE TABLE `task_receive_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `task_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '快递名称',
  `task_weight` decimal(10, 2) NULL DEFAULT NULL COMMENT '快递重量',
  `task_price` decimal(10, 2) NULL DEFAULT NULL COMMENT '代拿价格',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '发布人id',
  `user_avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '发布人头像',
  `task_id` bigint(20) NULL DEFAULT NULL COMMENT '任务id',
  `taker_id` int(11) NULL DEFAULT NULL COMMENT '接单者id',
  `state` tinyint(2) NULL DEFAULT NULL COMMENT '0 接单中 ,1 待完成 2完成 ,3 删除 ',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `modified_time` datetime NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of task_receive_info
-- ----------------------------
INSERT INTO `task_receive_info` VALUES (3, '茶杯', 2.50, 4.00, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 4, 6, 1, '2018-09-26 19:12:05', '2018-09-27 19:31:27');
INSERT INTO `task_receive_info` VALUES (5, '零食一堆', 2.50, 4.00, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 12, 6, 0, '2018-09-27 15:16:35', '2018-09-27 19:31:31');
INSERT INTO `task_receive_info` VALUES (6, '衣服', 222.00, 2.00, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 8, 6, 0, '2018-09-27 15:18:39', '2018-09-27 19:31:33');
INSERT INTO `task_receive_info` VALUES (7, '衣服2', 222.00, 2.00, 6, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 16, 6, 2, '2018-09-27 15:19:27', '2018-09-29 10:18:04');
INSERT INTO `task_receive_info` VALUES (10, '一双鞋', 32.00, 3.00, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 7, 6, 1, '2018-09-27 19:44:07', '2018-09-27 19:44:59');
INSERT INTO `task_receive_info` VALUES (12, '漫画', 8.60, 3.00, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 3, 6, 1, '2018-09-28 18:58:44', '2018-09-28 18:58:49');
INSERT INTO `task_receive_info` VALUES (13, '巧克力', 15.80, 1.50, 6, 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTILEE8TK9vgB8wggRUPgqrgicSVLVWrqwAAHfa9ia74m0n3dBdicQ0INESlxmVUoALYVM3ZQJRh3Bsgw/132', 20, 6, 1, '2018-09-28 19:00:08', '2018-09-28 19:00:12');
INSERT INTO `task_receive_info` VALUES (14, '方便面', 8.60, 3.00, 1, 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', 11, 6, 1, '2018-09-29 10:18:40', '2018-09-29 10:18:54');

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `nick_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `avatar_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '头像',
  `openid` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'openid',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `modified_time` datetime NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_openid`(`openid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES (1, '明明就不简单', 'http://qzapp.qlogo.cn/qzapp/101474546/B4A5784F27327150B4192A3111B0F107/50', '11154548484851', '2018-09-19 17:57:50', NULL);
INSERT INTO `user_info` VALUES (2, '树也草草', 'http://tva4.sinaimg.cn/crop.0.0.480.480.50/0068FpBFjw8esqzr6jhfyj30dc0dcwf3.jpg', '544848451212121', '2018-09-19 17:59:42', NULL);
INSERT INTO `user_info` VALUES (3, '7004', '8', '061EriUX05Aos22AzZWX0y7rUX0EriUy', NULL, '2018-09-25 17:15:27');
INSERT INTO `user_info` VALUES (4, '7004', '8', '061EriUX05Aos22AzZWX0y7rUX0Eri', '2018-09-25 17:15:38', NULL);
INSERT INTO `user_info` VALUES (5, '7004', '8', '061EriUX05Aos22AzZWX0y7rUX0E', '2018-09-25 17:18:26', NULL);
INSERT INTO `user_info` VALUES (6, '　　　', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTILEE8TK9vgB8wggRUPgqrgicSVLVWrqwAAHfa9ia74m0n3dBdicQ0INESlxmVUoALYVM3ZQJRh3Bsgw/132', 'oxcMH0eSP5lz9xn2DsDZCZzHYzbs', '2018-09-25 18:02:48', '2018-09-26 09:45:08');

SET FOREIGN_KEY_CHECKS = 1;
