<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/17
 * @desc:
 */



echo phpinfo();