<?php
/**
 * @author: 邵泽铭
 * @date: 2018/11/9
 * @desc:
 */

namespace app\index\utils;


class TempMessegeUtils
{


    public static function getData($type,$task,$user,$formId){
        $RECIEVE="pFQBaSPqsEGA29uX3Jkk20NTJL5Ov7lx9aWSF3bQs14";  //接收任务
        $END="2JQuvRKQc2wuI8QpjEKZFId3qIBQrWlkiCrrdGXFUvs";   //结束任务
        $CANCEL="twD0BmRTpyCLUyNxl207ti-GmY1PuMEWt2xqB0venJg"; //取消

        if($type==1){
            $template_id=$RECIEVE;
            $value = array(
                "keyword1"=>array(
                    "value"=>$task->task_name,
                    "color"=>"#4a4a4a"
                ),
                "keyword2"=>array(
                    "value"=>$user->nick_name,
                    "color"=>"#9b9b9b"
                ),
                "keyword3"=>array(
                    "value"=>date('Y-m-d H:i:s',time()),
                    "color"=>"#9b9b9b"
                )
            );

        }elseif ($type==2){
            $template_id=$END;
            $value = array(
                "keyword1"=>array(
                    "value"=>$task->task_name,
                    "color"=>"#4a4a4a"
                ),
                "keyword2"=>array(
                    "value"=>date('Y-m-d H:i:s',time()),
                    "color"=>"#9b9b9b"
                ),
                "keyword3"=>array(
                    "value"=>'您的任务已完成，请确认完成',
                    "color"=>"#9b9b9b"
                )
            );

        }elseif($type==3){

            $template_id=$CANCEL;
            $value = array(
                "keyword1"=>array(
                    "value"=>$task->task_name,
                    "color"=>"#4a4a4a"
                ),
                "keyword2"=>array(
                    "value"=>date('Y-m-d H:i:s',time()),
                    "color"=>"#9b9b9b"
                )
            );
        }


        $dd = array();
        $dd['touser']=$user->openid;
        $dd['template_id']=$template_id;
      //  $dd['page']=$page;  //点击模板卡片后的跳转页面，仅限本小程序内的页面。支持带参数,该字段不填则模板无跳转。
        $dd['form_id']=$formId;
        $dd['data']=$value;                        //模板内容，不填则下发空模板
        $dd['color']='#fff';                        //模板内容字体的颜色，不填默认黑色

        return $dd;
    }

}