<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/14
 * Time: 14:02
 */

namespace app\index\controller;


use app\index\model\TaskInfo;
use app\index\service\ReceiveService;
use app\index\service\TaskInfoService;
use think\Controller;
use think\exception\DbException;
use think\Request;

class TaskController extends  Controller
{
    public $taskInfoService;
    public $pickService;
    public function __construct(){
        parent::__construct();
        $this->taskInfoService=new TaskInfoService();
        $this->pickService=new ReceiveService();
    }
    public function getTaskList($page,$size=8,$schoolId){


        if(empty($page)||empty($schoolId)){
            $this->redirect('index/error');
        }else{
          return   $this->taskInfoService->getTaskList($page,$size,$schoolId,0);
        }

       return null;
    }

    public function saveTask($taskName,$taskWeight,$taskPrice,$taskAddr,$schoolId,$openid,$addressId,$consigneeName,$consigneeMobile){
        return  $this->taskInfoService->saveTask($taskName,$taskWeight,$taskPrice,$taskAddr,$schoolId,$openid,$addressId,$consigneeName,$consigneeMobile);
    }
    public function updateTask($taskName,$taskWeight,$taskPrice,$taskAddr,$schoolId,$openid,$addressId,$consigneeName,$consigneeMobile,$id){
        return  $this->taskInfoService->updateTask($taskName,$taskWeight,$taskPrice,$taskAddr,$schoolId,$openid,$addressId,$consigneeName,$consigneeMobile,$id);
    }

    public  function  saveReceive($taskId,$openid,$id){
        return $this->pickService->saveReceiveInfo($taskId,$openid,$id);
    }

    public  function  selectReceive($openid){
       return $this->pickService->selectReceive($openid);
    }

    public function  getTaskById($taskId){
        return $this->taskInfoService->getTaskById($taskId);
    }

    public  function  updateReceiveEnd($receiveId){
        return $this->pickService->updateReceiveEnd($receiveId);
    }
    public  function  updateReceiveDelete($receiveId){
        return $this->pickService->updateReceiveDelete($receiveId);
    }
    public  function  selectTaskByOpenId($openid){
        return $this->taskInfoService->selectTaskByOpenId($openid);
    }

    public  function  selectTaskConfirmed($openid){
        return $this->pickService->selectTaskConfirmed($openid);
    }

    public  function  deleteTaskById($id){
        return $this->taskInfoService->deleteTaskById($id);
    }

    public  function  selectTaskMineOver($openid,$page,$size){
        return $this->pickService->selectTaskMineOver($openid,$page,$size);
    }

    public  function  updateReceiveConfirmEnd($receiveId){
        return $this->pickService->updateReceiveConfirmEnd($receiveId);
    }

    public  function  selectTaskMinePublish($openid,$page,$size){
        return $this->taskInfoService->selectTaskMinePublish($openid,$page,$size);
    }
}