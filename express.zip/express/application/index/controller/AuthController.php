<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/17
 * @desc:
 */

namespace app\index\controller;


use app\index\service\TaskInfoService;
use app\index\service\UserService;
use app\index\utils\HttpClientUtils;
use app\index\utils\TempMessegeUtils;
use think\Controller;

class AuthController extends  Controller
{

    public $taskInfoService;
    public $userService;

    public function __construct(){
        parent::__construct();
        $this->userService=new UserService();
        $this->taskInfoService=new TaskInfoService();
    }

   public function getOpenId($code){
       $url='https://api.weixin.qq.com/sns/jscode2session?appid=wx769534252da8f614&secret=18e789b883b8c335bb534abd13025104&js_code='.$code.'&grant_type=authorization_code';
       $body=HttpClientUtils::get($url);
       return  $body;
   }

    public function getAceessToken(){
        $url='https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx769534252da8f614&secret=18e789b883b8c335bb534abd13025104';
         $body=HttpClientUtils::get($url);

        return  $body;
    }

    public function login($openid,$avatar,$nickname){

        if( $this->userService->selectUser($openid)==null){
            return json($this->userService->saveUser($openid,$avatar,$nickname)) ;
        } else{
            return   json($this->userService->updateUser($openid,$avatar,$nickname));
        }
    }

    public function selectUser($id){
       return $this->userService->selectUserById($id);
    }


    public function templeteMessege($formId,$taskId,$type,$token){
         $task= $this->taskInfoService->getTaskById($taskId);
         $user=$this->userService->selectUserById($task->user_id);
          $data= TempMessegeUtils::getData($type,$task,$user,$formId);
         $url = 'https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token='.$token;
         return json_encode(HttpClientUtils::post($url,$data)) ;

    }
}