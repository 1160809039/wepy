<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/25
 * @desc:
 */

namespace app\index\model;


use think\Model;

class AddressInfo extends  Model
{
    protected $table = 'address_info';
    protected $connection = 'db_config';
}