<?php
/**
 * @author: 邵泽铭
 * @date: 2018/9/25
 * @desc:
 */

namespace app\index\model;


use think\Model;

class UserInfo extends Model
{
    protected $table = 'user_info';
    protected $connection = 'db_config';
}